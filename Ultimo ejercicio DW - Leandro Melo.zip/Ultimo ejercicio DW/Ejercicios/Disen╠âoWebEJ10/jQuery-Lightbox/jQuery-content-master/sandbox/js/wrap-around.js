window.flkty = new Flickity( '#gallery1', {
  wrapAround: true,
} );

window.flkty2 = new Flickity( '#gallery2', {
} );

window.flkty6 = new Flickity( '#gallery6', {
  wrapAround: true,
  cellAlign: 'left',
} );

window.flkty4 = new Flickity( '#gallery4', {
  wrapAround: true,
  freeScroll: true,
} );

window.flky5 = new Flickity( '#gallery5', {
  freeScroll: true,
} );
